import React from 'react';
import {Composition} from 'remotion';
import {Main, MainProps, TOTAL_SECONDS} from './Main';
import {FPS, WIDTH, HEIGHT} from './theme';
import {sec} from './utils';

export const Root: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    durationInFrames={sec(TOTAL_SECONDS)}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
    // playVoiceover: Studio-তে voiceover on/off করতে Props panel থেকে বদলান
    defaultProps={{playVoiceover: true, playSfx: true} as MainProps}
  />
);
