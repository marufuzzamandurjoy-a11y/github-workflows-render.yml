import React from 'react';
import {AbsoluteFill, Img, interpolate, random, staticFile, useCurrentFrame} from 'remotion';
import {theme} from './theme';
import {at, enter, lightsPath, prog, sag, wave} from './utils';
import {Background, Center, DrawPath, Fade, GlassCard, Icon, Words} from './components';

type SceneProps = {t0: number};
const C = theme.colors;

// 1) HOOK — 0.0s
export const SceneHook: React.FC<SceneProps> = ({t0}) => {
  const frame = useCurrentFrame();
  const F = (a: number) => at(a, t0);
  const sunY = interpolate(frame, [0, 170], [500, 700], {extrapolateRight: 'clamp', easing: theme.ease.inOut});
  const rail = prog(frame, 10, 60);
  const lights = prog(frame, 20, 50);
  return (
    <AbsoluteFill>
      <Background variant="dusk" glowX={50} glowY={62} />
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute'}}>
        <defs>
          <radialGradient id="sunG">
            <stop offset="0%" stopColor={C.hero} />
            <stop offset="100%" stopColor={C.accent} />
          </radialGradient>
        </defs>
        <circle cx={960} cy={sunY} r={190} fill="url(#sunG)" opacity={0.95} />
        <rect x={0} y={760} width={1920} height={320} fill={C.bgDeep} />
        {[0, 1, 2, 3].map((i) => (
          <path
            key={i}
            d={wave(782 + i * 38, 9 + i * 3, frame * 0.03 * (1 + i * 0.3) + i, 1920)}
            fill="none"
            stroke={C.hero}
            strokeOpacity={0.55 - i * 0.1}
            strokeWidth={3}
          />
        ))}
        <DrawPath d="M0 930 H1920" p={rail} color={C.text} width={4} opacity={0.8} />
        {Array.from({length: 17}, (_, i) => (
          <DrawPath key={i} d={`M${60 + i * 112} 930 V1010`} p={rail} color={C.text} width={4} opacity={0.6} />
        ))}
        <path d={lightsPath()} fill="none" stroke={C.textDim} strokeWidth={2} opacity={lights} />
        {Array.from({length: 12}, (_, i) => {
          const x = 80 + i * 160;
          return (
            <circle
              key={i}
              cx={x}
              cy={sag(x)}
              r={9}
              fill={C.hero}
              opacity={lights * (0.55 + 0.45 * Math.sin(frame * 0.12 + i * 1.7))}
            />
          );
        })}
      </svg>
      <Center y="36%">
        <div style={{position: 'relative', height: 330, width: '100%'}}>
          <Fade out={F(2.75)} style={{position: 'absolute', inset: 0, display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
            <Words text="নদীর হাওয়া" delay={F(0.1)} size={170} />
          </Fade>
          <Fade out={F(4.2)} style={{position: 'absolute', inset: 0, display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
            <Words text="সন্ধ্যার আলো" delay={F(2.9)} size={170} highlight={[1]} />
          </Fade>
          <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center'}}>
            <Words text="আকাশের নিচে" delay={F(4.3)} size={64} color={C.textDim} weight={theme.font.semi} />
            <Words text="একটা রুফটপ" delay={F(4.6)} size={160} color={C.hero} />
          </div>
        </div>
      </Center>
    </AbsoluteFill>
  );
};

// 2) WELCOME — 6.0s
export const SceneWelcome: React.FC<SceneProps> = ({t0}) => {
  const frame = useCurrentFrame();
  const F = (a: number) => at(a, t0);
  const spin = frame * 0.4;
  return (
    <AbsoluteFill>
      <Background variant="warm" glowX={50} glowY={50} />
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute'}}>
        {[300, 420, 540].map((r, i) => (
          <circle
            key={i}
            cx={960}
            cy={540}
            r={r}
            fill="none"
            stroke={C.hero}
            strokeOpacity={0.22 - i * 0.05}
            strokeWidth={3}
            strokeDasharray="14 26"
            transform={`rotate(${i % 2 === 0 ? spin : -spin} 960 540)`}
          />
        ))}
      </svg>
      <Fade out={F(9.5)}>
        <Center y="50%">
          <Words text="ক্যাফে রিভারভিউ" delay={F(6.4)} size={130} />
          <Words text="এন্ড রুফটপ" delay={F(7.0)} size={80} color={C.textDim} weight={theme.font.semi} />
          <div style={{height: 30}} />
          <Words text="স্বাগতম" delay={F(8.3)} size={230} color={C.hero} />
        </Center>
      </Fade>
      <Center y="50%">
        <Words text="প্রতিটি সন্ধ্যা" delay={F(9.7)} size={120} />
        <Words text="একটু বিশেষ" delay={F(11.8)} size={190} color={C.hero} />
      </Center>
    </AbsoluteFill>
  );
};

// 3) TASTE (দেশি | বিদেশি) — 13.2s
export const SceneTaste: React.FC<SceneProps> = ({t0}) => {
  const frame = useCurrentFrame();
  const F = (a: number) => at(a, t0);
  const lift = interpolate(frame, [F(17.9), F(17.9) + 18], [0, -150], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: theme.ease.inOut,
  });
  const card = (x: number, name: 'bowl' | 'globe', label: string, delay: number) => {
    const p = enter(frame, delay);
    return (
      <div style={{position: 'absolute', left: x, top: 240, width: 640, height: 480}}>
        <GlassCard p={p} style={{width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20}}>
          <Icon name={name} size={190} p={prog(frame, delay, 30)} />
          <div style={{fontFamily: theme.font.family, fontWeight: 700, fontSize: 100, color: C.text, letterSpacing: 0}}>{label}</div>
        </GlassCard>
      </div>
    );
  };
  return (
    <AbsoluteFill>
      <Background variant="night" glowX={50} glowY={45} />
      <div style={{position: 'absolute', inset: 0, transform: `translateY(${lift}px)`}}>
        {card(220, 'bowl', 'দেশি স্বাদ', F(13.5))}
        {card(1060, 'globe', 'বিদেশি খাবার', F(15.4))}
      </div>
      <Center y="78%">
        <Words text="সবার জন্য" delay={F(18.0)} size={100} color={C.textDim} weight={theme.font.semi} />
        <Words text="কিছু না কিছু" delay={F(19.2)} size={130} color={C.hero} />
      </Center>
    </AbsoluteFill>
  );
};

// 4) MENU (চাইনিজ / বাংলা rows) — 21.6s
export const SceneMenu: React.FC<SceneProps> = ({t0}) => {
  const frame = useCurrentFrame();
  const F = (a: number) => at(a, t0);
  const row = (y: number, icon: 'noodle' | 'rice', small: string, big: string, delay: number) => {
    const p = enter(frame, delay);
    return (
      <div style={{position: 'absolute', left: 200, right: 200, top: y, height: 280}}>
        <GlassCard p={p} style={{height: '100%', display: 'flex', alignItems: 'center', gap: 60, padding: '0 70px'}}>
          <Icon name={icon} size={190} p={prog(frame, delay, 30)} />
          <div>
            <div style={{fontFamily: theme.font.family, fontWeight: 600, fontSize: 52, color: C.textDim, letterSpacing: 0}}>{small}</div>
            <div style={{fontFamily: theme.font.family, fontWeight: 700, fontSize: 130, color: C.text, letterSpacing: 0, lineHeight: 1.2}}>{big}</div>
          </div>
        </GlassCard>
      </div>
    );
  };
  return (
    <AbsoluteFill>
      <Background variant="warm" glowX={20} glowY={50} />
      {row(190, 'noodle', 'গরম গরম', 'চাইনিজ আইটেম', F(21.93))}
      {row(530, 'rice', 'ঘরোয়া স্বাদের', 'বাংলা খাবার', F(23.85))}
    </AbsoluteFill>
  );
};

// 5) BBQ — 26.0s
export const SceneBBQ: React.FC<SceneProps> = ({t0}) => {
  const frame = useCurrentFrame();
  const F = (a: number) => at(a, t0);
  const sparks = Array.from({length: 34}, (_, i) => i);
  return (
    <AbsoluteFill>
      <Background variant="fire" glowX={50} glowY={90} />
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute'}}>
        {sparks.map((i) => {
          const x = 380 + random(`sx${i}`) * 1160;
          const speed = 2 + random(`ss${i}`) * 3;
          const y = 980 - ((random(`sy${i}`) * 900 + frame * speed) % 900);
          const o = interpolate(y, [80, 980], [0, 0.9]);
          return <circle key={i} cx={x + Math.sin(frame * 0.05 + i) * 20} cy={y} r={3 + random(`sr${i}`) * 5} fill={C.ember} opacity={o} />;
        })}
      </svg>
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 40, display: 'flex', justifyContent: 'center', gap: 70, alignItems: 'flex-end'}}>
        {[0, 1, 2].map((i) => {
          const s = enter(frame, F(26.1) + i * 5);
          const flick = 1 + 0.07 * Math.sin(frame * 0.45 + i * 2);
          const size = i === 1 ? 420 : 320;
          return (
            <div key={i} style={{transform: `scale(${s}, ${s * flick})`, transformOrigin: '50% 100%', filter: `drop-shadow(0 0 40px ${C.accent})`}}>
              <Icon name="flame" size={size} p={1} color={i === 1 ? C.hero : C.ember} width={4} />
            </div>
          );
        })}
      </div>
      <Center y="30%">
        <Words text="আগুনে ঝলসানো" delay={F(26.7)} size={86} color={C.textDim} weight={theme.font.semi} />
        <Words text="বার-বি-কিউ" delay={F(28.3)} size={240} color={C.hero} />
        <Words text="ঘ্রাণেই খিদে জেগে ওঠে" delay={F(30.0)} size={70} color={C.text} weight={theme.font.semi} />
      </Center>
    </AbsoluteFill>
  );
};

// 6) RIVER timeline — 31.8s
export const SceneRiver: React.FC<SceneProps> = ({t0}) => {
  const frame = useCurrentFrame();
  const F = (a: number) => at(a, t0);
  const river = prog(frame, F(32.0), 135);
  const node = (x: number, text: string, delay: number) => {
    const p = enter(frame, delay);
    return (
      <div key={x} style={{position: 'absolute', left: x - 250, top: 330, width: 500, textAlign: 'center', opacity: Math.min(1, p * 1.5), transform: `translateY(${(1 - p) * 40}px)`}}>
        <div style={{fontFamily: theme.font.family, fontWeight: 700, fontSize: 84, color: C.text, letterSpacing: 0, lineHeight: 1.3}}>{text}</div>
        <div style={{margin: '14px auto 0', width: 3, height: 140 * p, background: C.hero}} />
        <div style={{margin: '0 auto', width: 26, height: 26, borderRadius: '50%', background: C.hero, boxShadow: `0 0 30px ${C.hero}`}} />
      </div>
    );
  };
  return (
    <AbsoluteFill>
      <Background variant="night" glowX={78} glowY={18} />
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute'}}>
        <circle cx={1560} cy={170} r={70} fill={C.text} opacity={0.9} />
        <circle cx={1590} cy={150} r={64} fill={C.bgDeep} />
        {Array.from({length: 40}, (_, i) => (
          <circle key={i} cx={random(`tx${i}`) * 1920} cy={random(`ty${i}`) * 520} r={1.5 + random(`tr${i}`) * 2.5} fill={C.text} opacity={0.3 + 0.5 * Math.abs(Math.sin(frame * 0.05 + i))} />
        ))}
        <DrawPath d="M-40 800 C240 730 480 870 760 800 S1280 730 1560 800 S1800 850 1960 800" p={river} color={C.hero} width={16} opacity={0.9} />
        <DrawPath d="M-40 850 C240 780 480 920 760 850 S1280 780 1560 850 S1800 900 1960 850" p={river} color={C.textDim} width={4} opacity={0.6} />
      </svg>
      {node(360, 'নদীর ধারে', F(32.13))}
      {node(960, 'খোলা আকাশ', F(33.55))}
      {node(1560, 'প্রিয় মানুষ', F(35.26))}
    </AbsoluteFill>
  );
};

// 7) MOOD split (নিরিবিলি | হইচই) — 37.3s
export const SceneMood: React.FC<SceneProps> = ({t0}) => {
  const frame = useCurrentFrame();
  const F = (a: number) => at(a, t0);
  const split = prog(frame, 0, 20);
  return (
    <AbsoluteFill>
      <Background variant="night" glowX={25} glowY={50} />
      <div style={{position: 'absolute', right: 0, top: 0, bottom: 0, width: 960, background: 'radial-gradient(circle at 50% 55%, rgba(245,158,11,0.22), rgba(245,158,11,0) 65%)'}} />
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute'}}>
        <DrawPath d="M960 80 V1000" p={split} color={C.textDim} width={3} />
        {[0, 1, 2].map((i) => (
          <circle key={i} cx={480} cy={540} r={110 + i * 70 + 10 * Math.sin(frame * 0.03 + i)} fill="none" stroke={C.text} strokeOpacity={0.18 - i * 0.04} strokeWidth={3} />
        ))}
        {Array.from({length: 11}, (_, i) => {
          const h = 60 + 150 * Math.abs(Math.sin(frame * 0.18 + i * 0.9)) * (0.6 + random(`b${i}`) * 0.6);
          return <rect key={i} x={1130 + i * 60} y={540 - h / 2} width={34} height={h} rx={17} fill={C.hero} opacity={0.75} />;
        })}
      </svg>
      <div style={{position: 'absolute', left: 0, width: 960, top: 640, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
        <Words text="পরিবারের সাথে" delay={F(37.59)} size={56} color={C.textDim} weight={theme.font.semi} />
        <Words text="নিরিবিলি সন্ধ্যা" delay={F(38.0)} size={96} />
      </div>
      <div style={{position: 'absolute', left: 960, width: 960, top: 690, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
        <Words text="বন্ধুদের সাথে" delay={F(39.76)} size={56} color={C.textDim} weight={theme.font.semi} />
        <Words text="হইচই" delay={F(40.1)} size={130} color={C.hero} />
      </div>
    </AbsoluteFill>
  );
};

// 8) PARTY — 42.0s
export const SceneParty: React.FC<SceneProps> = ({t0}) => {
  const frame = useCurrentFrame();
  const F = (a: number) => at(a, t0);
  const burst = prog(frame, F(48.0), 60);
  const chip = (x: number, label: string, delay: number) => {
    const p = enter(frame, delay, theme.spring.pop);
    return (
      <div key={label} style={{opacity: Math.min(1, p * 1.5), transform: `scale(${0.6 + 0.4 * p})`}}>
        <div style={{fontFamily: theme.font.family, fontWeight: 700, fontSize: 70, color: C.bgDeep, background: C.hero, borderRadius: theme.radius.chip, padding: '18px 54px', letterSpacing: 0, boxShadow: '0 20px 50px rgba(0,0,0,0.4)'}}>{label}</div>
      </div>
    );
  };
  return (
    <AbsoluteFill>
      <Background variant="dusk" glowX={50} glowY={50} />
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute'}}>
        <path d={lightsPath()} fill="none" stroke={C.textDim} strokeWidth={2} opacity={0.6} />
        {Array.from({length: 12}, (_, i) => {
          const x = 80 + i * 160;
          return <circle key={i} cx={x} cy={sag(x)} r={9} fill={C.hero} opacity={0.6 + 0.4 * Math.sin(frame * 0.14 + i * 1.3)} />;
        })}
        {Array.from({length: 46}, (_, i) => {
          const a = random(`ca${i}`) * Math.PI * 2;
          const d = (120 + random(`cd${i}`) * 700) * burst;
          const colors = [C.hero, C.accent, C.ember, C.text];
          return <circle key={i} cx={960 + Math.cos(a) * d * 1.5} cy={560 + Math.sin(a) * d * 0.8 + burst * burst * 90} r={5 + random(`cr${i}`) * 7} fill={colors[i % 4]} opacity={(1 - burst * 0.35) * burst} />;
        })}
      </svg>
      <Fade out={F(46.1)}>
        <Center y="50%">
          <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 36}}>
            {chip(0, 'জন্মদিন', F(42.45))}
            {chip(0, 'পারিবারিক অনুষ্ঠান', F(43.45))}
            {chip(0, 'বন্ধুদের পার্টি', F(44.8))}
          </div>
        </Center>
      </Fade>
      <Center y="50%">
        <Words text="সব আয়োজনের জন্য" delay={F(46.4)} size={84} color={C.textDim} weight={theme.font.semi} />
        <Words text="পার্টি সেন্টার" delay={F(48.0)} size={230} color={C.hero} />
      </Center>
    </AbsoluteFill>
  );
};

// 9) HUB & SPOKE — 49.9s
export const SceneHub: React.FC<SceneProps> = ({t0}) => {
  const frame = useCurrentFrame();
  const F = (a: number) => at(a, t0);
  const cx = 960;
  const cy = 540;
  const nodes = [
    {x: cx, y: 190, label: 'খাবার', d: F(51.7)},
    {x: cx + 430, y: 770, label: 'আড্ডা', d: F(52.4)},
    {x: cx - 430, y: 770, label: 'নদীর দৃশ্য', d: F(53.0)},
  ];
  return (
    <AbsoluteFill>
      <Background variant="warm" glowX={50} glowY={50} />
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute'}}>
        {nodes.map((n, i) => (
          <DrawPath key={i} d={`M${cx} ${cy} L${n.x} ${n.y}`} p={prog(frame, n.d - 6, 16)} color={C.hero} width={4} opacity={0.8} />
        ))}
      </svg>
      <div style={{position: 'absolute', left: cx - 200, top: cy - 200, width: 400, height: 400, borderRadius: '50%', background: C.hero, display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center', transform: `scale(${enter(frame, F(50.28), theme.spring.pop)})`, boxShadow: '0 0 90px rgba(245,158,11,0.5)'}}>
        <div style={{fontFamily: theme.font.family, fontWeight: 700, fontSize: 70, color: C.bgDeep, letterSpacing: 0, lineHeight: 1.3}}>
          এক
          <br />
          জায়গাতেই
        </div>
      </div>
      {nodes.map((n, i) => {
        const p = enter(frame, n.d);
        return (
          <div key={i} style={{position: 'absolute', left: n.x - 200, top: n.y - 70, width: 400, height: 140}}>
            <GlassCard p={p} style={{height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
              <div style={{fontFamily: theme.font.family, fontWeight: 700, fontSize: 76, color: C.text, letterSpacing: 0}}>{n.label}</div>
            </GlassCard>
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

// 10) PAUSE (minimal) — 54.3s
export const ScenePause: React.FC<SceneProps> = ({t0}) => {
  const frame = useCurrentFrame();
  const F = (a: number) => at(a, t0);
  const breathe = 1 + 0.06 * Math.sin(frame * 0.07);
  return (
    <AbsoluteFill>
      <Background variant="night" glowX={50} glowY={50} />
      <div style={{position: 'absolute', left: 960 - 380, top: 540 - 380, width: 760, height: 760, borderRadius: '50%', background: 'radial-gradient(circle, rgba(245,158,11,0.28), rgba(245,158,11,0) 68%)', transform: `scale(${breathe})`}} />
      <Fade out={F(55.7)}>
        <Center y="50%">
          <Words text="দিনের ক্লান্তি" delay={F(54.75)} size={110} color={C.textDim} />
        </Center>
      </Fade>
      <Fade out={F(57.0)}>
        <Center y="50%">
          <Words text="একটু থামুন" delay={F(55.75)} size={190} color={C.hero} />
        </Center>
      </Fade>
      <Center y="50%">
        <Words text="নদীর পাশে একটা সন্ধ্যা" delay={F(57.1)} size={100} />
        <Words text="আপনার অপেক্ষায়" delay={F(58.8)} size={130} color={C.hero} />
      </Center>
    </AbsoluteFill>
  );
};

// 11) TAGLINE — 60.2s
export const SceneTagline: React.FC<SceneProps> = ({t0}) => {
  const frame = useCurrentFrame();
  const F = (a: number) => at(a, t0);
  const sweep = prog(frame, F(62.6), 22);
  return (
    <AbsoluteFill>
      <Background variant="dusk" glowX={50} glowY={55} />
      {[0, 1, 2].map((i) => (
        <div key={i} style={{position: 'absolute', left: 300 + i * 420 + 90 * Math.sin(frame * 0.02 + i * 2), top: 200 + 140 * Math.cos(frame * 0.025 + i), width: 520, height: 520, borderRadius: '50%', background: i === 1 ? C.accent : C.hero, opacity: 0.12, filter: 'blur(90px)'}} />
      ))}
      <Center y="50%">
        <Words text="আসুন," delay={F(60.5)} size={90} color={C.textDim} weight={theme.font.semi} />
        <Words text="এই সন্ধ্যাটা হোক" delay={F(61.2)} size={130} />
        <div style={{position: 'relative'}}>
          <Words text="একটু অন্যরকম" delay={F(62.4)} size={200} color={C.hero} />
          <div style={{position: 'absolute', left: '8%', bottom: 6, height: 10, width: `${84 * sweep}%`, background: C.accent, borderRadius: 6}} />
        </div>
      </Center>
    </AbsoluteFill>
  );
};

// 12) WHERE — 64.2s
export const SceneWhere: React.FC<SceneProps> = ({t0}) => {
  const frame = useCurrentFrame();
  const F = (a: number) => at(a, t0);
  const bob = 8 * Math.sin(frame * 0.12);
  const row = (y: number, text: string, delay: number) => {
    const p = enter(frame, delay);
    return (
      <div key={text} style={{position: 'absolute', left: 760, right: 140, top: y, height: 170}}>
        <GlassCard p={p} style={{height: '100%', display: 'flex', alignItems: 'center', padding: '0 60px'}}>
          <div style={{fontFamily: theme.font.family, fontWeight: 700, fontSize: 84, color: C.text, letterSpacing: 0}}>{text}</div>
        </GlassCard>
      </div>
    );
  };
  return (
    <AbsoluteFill>
      <Background variant="warm" glowX={25} glowY={50} />
      <div style={{position: 'absolute', left: 120, top: 250 + bob, filter: `drop-shadow(0 0 40px ${C.hero})`}}>
        <Icon name="pin" size={480} p={prog(frame, F(64.3), 36)} />
      </div>
      <div style={{position: 'absolute', left: 760, top: 150}}>
        <Words text="ঠিকানা" delay={F(64.4)} size={64} color={C.textDim} weight={theme.font.semi} align="left" />
      </div>
      {row(290, 'শুকরিয়া মার্কেট', F(64.6))}
      {row(500, '২য় ও ৩য় তলা', F(65.9))}
      {row(710, 'গাজিরহাট, বাংগরা', F(67.4))}
    </AbsoluteFill>
  );
};

// 13) OUTRO — 69.0s
export const SceneOutro: React.FC<SceneProps> = ({t0}) => {
  const frame = useCurrentFrame();
  const F = (a: number) => at(a, t0);
  const lp = enter(frame, F(69.3), theme.spring.pop);
  const glow = 0.5 + 0.5 * Math.sin(frame * 0.06);
  return (
    <AbsoluteFill>
      <Background variant="dusk" glowX={28} glowY={50} />
      <div
        style={{
          position: 'absolute',
          left: 110,
          top: 540 - 216,
          width: 820,
          height: 431,
          borderRadius: theme.radius.logo,
          overflow: 'hidden',
          opacity: Math.min(1, lp * 1.5),
          transform: `scale(${0.85 + 0.15 * lp})`,
          boxShadow: `0 0 ${60 + 40 * glow}px rgba(239,68,68,0.55)`,
        }}
      >
        <Img src={staticFile('assets/cafe-logo.jpg')} style={{width: '100%', height: '100%', objectFit: 'contain'}} />
      </div>
      <div style={{position: 'absolute', left: 1010, right: 90, top: 0, bottom: 0, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 18}}>
        <Words text="ক্যাফে রিভারভিউ এন্ড রুফটপ" delay={F(69.6)} size={72} align="left" />
        <Words text="স্বাদ আর নদীর গল্প" delay={F(71.45)} size={62} color={C.hero} align="left" weight={theme.font.semi} />
        <div style={{height: 16}} />
        <Words text="ফোন" delay={F(74.1)} size={46} color={C.textDim} align="left" weight={theme.font.semi} />
        <Words text="01855-858080" delay={F(74.2)} size={108} color={C.hero} align="left" />
        <Words text="শুকরিয়া মার্কেট, ২য় ও ৩য় তলা, গাজিরহাট, বাংগরা" delay={F(76.0)} size={36} color={C.textDim} align="left" weight={theme.font.semi} />
      </div>
    </AbsoluteFill>
  );
};
