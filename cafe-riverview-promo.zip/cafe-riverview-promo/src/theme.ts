import {Easing} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';

const {fontFamily} = loadFont('normal', {
  weights: ['500', '600', '700'],
  subsets: ['bengali', 'latin'],
});

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// Color scheme: Sunset Rooftop
export const theme = {
  colors: {
    bg: '#1A0F0A',
    bgMid: '#3B1A12',
    bgDeep: '#0F0805',
    hero: '#F59E0B',
    ember: '#FB923C',
    accent: '#EF4444',
    text: '#FFF7ED',
    textDim: 'rgba(255,247,237,0.62)',
    glass: 'rgba(255,247,237,0.08)',
    glassBorder: 'rgba(255,247,237,0.2)',
    gradients: {
      dusk: 'linear-gradient(180deg, #1A0F0A 0%, #3B1A12 55%, #7A2E12 100%)',
      fire: 'radial-gradient(ellipse at 50% 100%, #8A2410 0%, #1A0F0A 68%)',
      night: 'linear-gradient(180deg, #0F0805 0%, #1A0F0A 60%, #2A1510 100%)',
      warm: 'radial-gradient(circle at 50% 40%, #4A2014 0%, #1A0F0A 72%)',
    },
  },
  font: {family: fontFamily, regular: 500, semi: 600, bold: 700},
  radius: {card: 36, chip: 999, logo: 40},
  shadow: {card: '0 30px 80px rgba(0,0,0,0.45)'},
  spacing: {margin: 120, gap: 32},
  spring: {
    soft: {damping: 20, stiffness: 120, mass: 0.9},
    pop: {damping: 12, stiffness: 180, mass: 0.7},
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.65, 0, 0.35, 1),
  },
  dur: {fade: 12},
};
