import React from 'react';
import {AbsoluteFill, interpolate, random, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {enter} from '../utils';

// ---------- Background (gradient + glow + drifting bokeh) ----------
export type BgVariant = 'dusk' | 'fire' | 'night' | 'warm';

export const Background: React.FC<{variant?: BgVariant; glowX?: number; glowY?: number}> = ({
  variant = 'warm',
  glowX = 50,
  glowY = 50,
}) => {
  const frame = useCurrentFrame();
  const dots = Array.from({length: 16}, (_, i) => i);
  return (
    <AbsoluteFill style={{background: theme.colors.gradients[variant]}}>
      <AbsoluteFill
        style={{
          background: `radial-gradient(circle at ${glowX}% ${glowY}%, rgba(245,158,11,${
            0.16 + 0.04 * Math.sin(frame * 0.04)
          }) 0%, rgba(245,158,11,0) 55%)`,
        }}
      />
      {dots.map((i) => {
        const size = 24 + random(`s${i}`) * 70;
        const x = random(`x${i}`) * 1920;
        const speed = 0.12 + random(`v${i}`) * 0.25;
        const y = 1180 - ((random(`y${i}`) * 1300 + frame * speed) % 1300);
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x,
              top: y,
              width: size,
              height: size,
              borderRadius: '50%',
              background: theme.colors.hero,
              opacity: 0.05 + random(`o${i}`) * 0.07,
              filter: 'blur(6px)',
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

// ---------- Words: word-by-word mask reveal (split by whitespace only) ----------
type WordsProps = {
  text: string;
  delay: number;
  size?: number;
  color?: string;
  weight?: number;
  stagger?: number;
  align?: 'left' | 'center' | 'right';
  highlight?: number[];
  highlightColor?: string;
  style?: React.CSSProperties;
};

export const Words: React.FC<WordsProps> = ({
  text,
  delay,
  size = 120,
  color = theme.colors.text,
  weight = theme.font.bold,
  stagger = 4,
  align = 'center',
  highlight = [],
  highlightColor = theme.colors.hero,
  style,
}) => {
  const frame = useCurrentFrame();
  const words = text.split(/\s+/).filter(Boolean);
  const justify = align === 'center' ? 'center' : align === 'left' ? 'flex-start' : 'flex-end';
  return (
    <div
      style={{
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: justify,
        columnGap: size * 0.28,
        fontFamily: theme.font.family,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.25,
        letterSpacing: 0,
        color,
        ...style,
      }}
    >
      {words.map((w, i) => {
        const p = enter(frame, delay + i * stagger);
        return (
          <span
            key={i}
            style={{display: 'inline-block', overflow: 'hidden', paddingTop: size * 0.12, paddingBottom: size * 0.12}}
          >
            <span
              style={{
                display: 'inline-block',
                transform: `translateY(${(1 - p) * 110}%)`,
                opacity: Math.min(1, p * 1.6),
                color: highlight.includes(i) ? highlightColor : color,
              }}
            >
              {w}
            </span>
          </span>
        );
      })}
    </div>
  );
};

// ---------- Fade: fades children out starting at frame `out` ----------
export const Fade: React.FC<{out?: number; children: React.ReactNode; style?: React.CSSProperties}> = ({
  out,
  children,
  style,
}) => {
  const frame = useCurrentFrame();
  const o = out === undefined ? 1 : interpolate(frame, [out, out + 8], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return <div style={{opacity: o, ...style}}>{children}</div>;
};

// Centered block anchored at a vertical position
export const Center: React.FC<{y?: string; children: React.ReactNode}> = ({y = '50%', children}) => (
  <div
    style={{
      position: 'absolute',
      left: 0,
      right: 0,
      top: y,
      transform: 'translateY(-50%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      padding: '0 120px',
    }}
  >
    {children}
  </div>
);

// ---------- Glass card ----------
export const GlassCard: React.FC<{p?: number; style?: React.CSSProperties; children?: React.ReactNode}> = ({
  p = 1,
  style,
  children,
}) => (
  <div
    style={{
      background: theme.colors.glass,
      border: `2px solid ${theme.colors.glassBorder}`,
      borderRadius: theme.radius.card,
      boxShadow: theme.shadow.card,
      backdropFilter: 'blur(18px)',
      opacity: Math.min(1, p * 1.5),
      transform: `translateY(${(1 - p) * 60}px) scale(${0.92 + 0.08 * p})`,
      ...style,
    }}
  >
    {children}
  </div>
);

// ---------- Line draw ----------
export const DrawPath: React.FC<{d: string; p: number; color?: string; width?: number; opacity?: number}> = ({
  d,
  p,
  color = theme.colors.text,
  width = 4,
  opacity = 1,
}) => (
  <path
    d={d}
    pathLength={1}
    strokeDasharray={1}
    strokeDashoffset={1 - p}
    fill="none"
    stroke={color}
    strokeWidth={width}
    strokeLinecap="round"
    strokeLinejoin="round"
    opacity={opacity}
  />
);

// ---------- Original line icons (viewBox 0 0 120 120) ----------
const ICONS = {
  bowl: [
    'M18 52 H102 C102 84 82 100 60 100 C38 100 18 84 18 52 Z',
    'M44 106 H76',
    'M44 38 C39 28 51 26 45 14',
    'M60 38 C55 28 67 26 61 14',
    'M76 38 C71 28 83 26 77 14',
  ],
  globe: [
    'M100 60 A40 40 0 1 1 20 60 A40 40 0 1 1 100 60',
    'M78 60 A18 40 0 1 1 42 60 A18 40 0 1 1 78 60',
    'M20 60 H100',
    'M27 38 H93',
    'M27 82 H93',
  ],
  noodle: [
    'M18 62 H102 C102 90 82 104 60 104 C38 104 18 90 18 62 Z',
    'M30 62 C36 50 44 74 52 56 C58 46 66 74 74 56 C80 48 86 66 90 60',
    'M74 8 L50 56',
    'M92 14 L66 58',
  ],
  rice: [
    'M26 74 C26 36 94 36 94 74 Z',
    'M12 80 H108',
    'M30 92 H90',
    'M60 36 C58 26 66 22 64 12',
  ],
  flame: [
    'M60 10 C70 35 92 46 88 76 C85 100 68 108 60 108 C44 108 30 96 32 76 C33 62 44 56 48 42 C52 52 56 50 60 10 Z',
    'M60 62 C66 76 76 80 72 92 C70 100 64 102 60 102 C52 102 48 94 50 86 C52 76 58 74 60 62 Z',
  ],
  pin: [
    'M60 108 C60 108 24 70 24 48 A36 36 0 0 1 96 48 C96 70 60 108 60 108 Z',
    'M72 48 A12 12 0 1 1 48 48 A12 12 0 1 1 72 48',
  ],
  skewer: [
    'M12 108 L108 12',
    'M50 80 A10 10 0 1 1 30 80 A10 10 0 1 1 50 80',
    'M70 60 A10 10 0 1 1 50 60 A10 10 0 1 1 70 60',
    'M90 40 A10 10 0 1 1 70 40 A10 10 0 1 1 90 40',
  ],
} as const;
export type IconName = keyof typeof ICONS;

export const Icon: React.FC<{name: IconName; size?: number; p?: number; color?: string; width?: number}> = ({
  name,
  size = 160,
  p = 1,
  color = theme.colors.hero,
  width = 5,
}) => (
  <svg width={size} height={size} viewBox="0 0 120 120" fill="none">
    {ICONS[name].map((d, i) => (
      <DrawPath key={i} d={d} p={p} color={color} width={width} />
    ))}
  </svg>
);
