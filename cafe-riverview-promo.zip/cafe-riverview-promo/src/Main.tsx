import React from 'react';
import {AbsoluteFill, Audio, interpolate, Sequence, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme} from './theme';
import {sec} from './utils';
import {
  SceneHook, SceneWelcome, SceneTaste, SceneMenu, SceneBBQ, SceneRiver, SceneMood,
  SceneParty, SceneHub, ScenePause, SceneTagline, SceneWhere, SceneOutro,
} from './scenes';

export type MainProps = {playVoiceover: boolean; playSfx: boolean};

// Voiceover = 78.3s; extra tail so the logo / phone number can hold.
export const TOTAL_SECONDS = 80;
const OVERLAP = theme.dur.fade;

// Scene start times (seconds) — derived from the voiceover pauses (voiceover.srt)
const scenes: {start: number; Comp: React.FC<{t0: number}>}[] = [
  {start: 0.0, Comp: SceneHook},
  {start: 6.0, Comp: SceneWelcome},
  {start: 13.2, Comp: SceneTaste},
  {start: 21.6, Comp: SceneMenu},
  {start: 26.0, Comp: SceneBBQ},
  {start: 31.8, Comp: SceneRiver},
  {start: 37.3, Comp: SceneMood},
  {start: 42.0, Comp: SceneParty},
  {start: 49.9, Comp: SceneHub},
  {start: 54.3, Comp: ScenePause},
  {start: 60.2, Comp: SceneTagline},
  {start: 64.2, Comp: SceneWhere},
  {start: 69.0, Comp: SceneOutro},
];

type Sfx = {t: number; type: 'pop' | 'click' | 'whoosh' | 'chime' | 'impact'; vol?: number; rate?: number};
const SFX: Sfx[] = [
  {t: 5.9, type: 'whoosh'},
  {t: 13.1, type: 'whoosh'},
  {t: 13.5, type: 'pop'},
  {t: 15.4, type: 'pop', rate: 1.08},
  {t: 21.5, type: 'whoosh'},
  {t: 21.95, type: 'pop'},
  {t: 23.85, type: 'pop', rate: 1.08},
  {t: 28.3, type: 'impact', vol: 0.3},
  {t: 31.7, type: 'whoosh'},
  {t: 42.45, type: 'click'},
  {t: 43.45, type: 'click', rate: 1.06},
  {t: 44.8, type: 'click', rate: 1.12},
  {t: 47.9, type: 'pop'},
  {t: 51.7, type: 'click'},
  {t: 52.4, type: 'click', rate: 1.06},
  {t: 53.0, type: 'click', rate: 1.12},
  {t: 62.4, type: 'impact', vol: 0.3},
  {t: 64.1, type: 'whoosh'},
  {t: 64.6, type: 'pop'},
  {t: 68.9, type: 'whoosh'},
  {t: 69.3, type: 'chime'},
  {t: 74.1, type: 'chime', rate: 1.12, vol: 0.22},
];

const SceneShell: React.FC<{first: boolean; last: boolean; children: React.ReactNode}> = ({first, last, children}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const opacity = interpolate(
    frame,
    [0, OVERLAP, durationInFrames - OVERLAP, durationInFrames],
    [first ? 1 : 0, 1, 1, last ? 1 : 0],
    {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'},
  );
  const scale = interpolate(frame, [0, durationInFrames], [1, 1.03]);
  return <AbsoluteFill style={{opacity, transform: `scale(${scale})`}}>{children}</AbsoluteFill>;
};

export const Main: React.FC<MainProps> = ({playVoiceover, playSfx}) => {
  return (
    <AbsoluteFill style={{backgroundColor: theme.colors.bg}}>
      {scenes.map((s, i) => {
        const from = sec(s.start);
        const end = i < scenes.length - 1 ? sec(scenes[i + 1].start) + OVERLAP : sec(TOTAL_SECONDS);
        return (
          <Sequence key={i} from={from} durationInFrames={end - from}>
            <SceneShell first={i === 0} last={i === scenes.length - 1}>
              <s.Comp t0={s.start} />
            </SceneShell>
          </Sequence>
        );
      })}
      {playVoiceover && <Audio src={staticFile('voiceover.mp3')} volume={1} />}
      {playSfx &&
        SFX.map((e, i) => (
          <Sequence key={i} from={sec(e.t)} durationInFrames={sec(1)}>
            <Audio src={staticFile(`sfx/${e.type}.wav`)} volume={e.vol ?? 0.28} playbackRate={e.rate ?? 1} />
          </Sequence>
        ))}
    </AbsoluteFill>
  );
};
