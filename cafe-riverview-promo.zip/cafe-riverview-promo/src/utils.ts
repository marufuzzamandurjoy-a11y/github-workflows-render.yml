import {spring} from 'remotion';
import {FPS, theme} from './theme';

export const sec = (s: number) => Math.round(s * FPS);

// absolute second -> local frame inside a scene (appears `lead` frames before the voice)
export const at = (abs: number, t0: number, lead = 4) =>
  Math.max(0, sec(abs - t0) - lead);

type SpringCfg = {damping: number; stiffness: number; mass: number};
export const enter = (frame: number, delay: number, config: SpringCfg = theme.spring.soft) =>
  spring({frame: frame - delay, fps: FPS, config});

export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
export const prog = (frame: number, from: number, dur: number) => clamp01((frame - from) / dur);

export const wave = (y: number, amp: number, phase: number, w: number) => {
  let d = `M0 ${y}`;
  for (let x = 0; x <= w; x += 20) {
    d += ` L${x} ${(y + Math.sin(x * 0.012 + phase) * amp).toFixed(1)}`;
  }
  return d;
};

export const sag = (x: number) => 110 + 70 * Math.sin(Math.PI * ((x % 480) / 480));
export const lightsPath = () => {
  let d = `M0 ${sag(0)}`;
  for (let x = 16; x <= 1920; x += 16) d += ` L${x} ${sag(x).toFixed(1)}`;
  return d;
};
