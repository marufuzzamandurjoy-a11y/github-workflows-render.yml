# Original synthesized SFX (no samples, copyright-safe). Run: python3 tools/generate-sfx.py
import numpy as np, wave, os
from scipy.signal import butter, sosfilt
SR = 44100
out = os.path.join(os.path.dirname(__file__), '..', 'public', 'sfx')
os.makedirs(out, exist_ok=True)
rng = np.random.default_rng(7)

def t_(d): return np.arange(int(SR * d)) / SR

def finish(x, name, peak=0.85):
    n = int(SR * 0.012)
    x = x.copy(); x[-n:] *= np.linspace(1, 0, n)
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    with wave.open(os.path.join(out, name + '.wav'), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype(np.int16).tobytes())

# pop: short pitched sine with fast envelope
t = t_(0.18); f = 700 * np.exp(-t * 9) + 260
finish(np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 26), 'pop')

# click: short band-passed noise burst
t = t_(0.09); n = rng.standard_normal(len(t))
n = sosfilt(butter(4, [1800, 7000], 'bandpass', fs=SR, output='sos'), n)
finish(n * np.exp(-t * 90), 'click')

# whoosh: noise swelling through a sweeping low-pass, band-limited
d = 0.7; t = t_(d); n = rng.standard_normal(len(t))
a = np.interp(t, [0, d * 0.5, d], [0.01, 0.22, 0.04]); y = np.zeros_like(n); s = 0.0
for i in range(len(n)):
    s += a[i] * (n[i] - s); y[i] = s
y = sosfilt(butter(2, 250, 'highpass', fs=SR, output='sos'), y)
env = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 2
finish(y * env, 'whoosh', 0.8)

# chime: soft pluck with two overtones, short decay
t = t_(0.55)
x = (np.sin(2*np.pi*880*t) + 0.4*np.sin(2*np.pi*1320*t) + 0.18*np.sin(2*np.pi*1760*t)) * np.exp(-t * 8)
x *= np.minimum(1, t / 0.004)
finish(x, 'chime', 0.8)

# impact: very soft low thump
t = t_(0.4); f = 46 + 44 * np.exp(-t * 18)
x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 11)
x += 0.05 * sosfilt(butter(2, 400, 'lowpass', fs=SR, output='sos'), rng.standard_normal(len(t))) * np.exp(-t * 30)
finish(x, 'impact', 0.85)
print('SFX written to', os.path.abspath(out))
